#!/usr/bin/env python3
"""R8F reviewer verifier: never modifies or prints source file contents."""
import argparse
import hashlib
import json
from pathlib import Path
import sys


def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while data := f.read(1048576):
            h.update(data)
    return h.hexdigest()


def main():
    a=argparse.ArgumentParser()
    a.add_argument('--package-only',action='store_true')
    a.add_argument('--source-dir',type=Path,default=Path.home()/'Downloads')
    args=a.parse_args()
    p=Path(__file__).resolve().parent
    checks=p/'SHA256SUMS'
    for line in checks.read_text(encoding='utf-8').splitlines():
        key,rel=line.split('  ',1)
        f=p/rel
        if f.is_symlink() or not f.is_file() or digest(f)!=key:
            raise SystemExit('STOP=PACKAGE_CONTENT_HASH_MISMATCH:'+rel)
    data=json.loads((p/'manifest.json').read_text(encoding='utf-8'))
    files=data['source_files']
    if len(files)!=29 or len({f['relative_path'] for f in files})!=29:
        raise SystemExit('STOP=MANIFEST_INVENTORY_INVALID')
    print('R8F_PACKAGE_CONTENT_HASHES=PASS')
    if args.package_only:
        print('R8F_SOURCE_VERIFICATION=NOT_REQUESTED')
        print('FINAL_RC=0')
        return
    base=args.source_dir
    if base.is_symlink() or not base.is_dir():
        raise SystemExit('STOP=SOURCE_BASE_INVALID')
    root=base/'PROOFSPEC_P6_19_READONLY_FINALITY_EVIDENCE'
    if root.is_symlink() or not root.is_dir():
        raise SystemExit('STOP=P6_DIRECTORY_INVALID')
    actual=[]
    for f in root.rglob('*'):
        if f.is_symlink():
            raise SystemExit('STOP=SYMLINK_IN_SOURCE_TREE')
        if f.is_file():
            actual.append(str(f.relative_to(base)))
        elif not f.is_dir():
            raise SystemExit('STOP=UNSUPPORTED_SOURCE_ENTRY')
    expected={f['relative_path'] for f in files if f['relative_path'].startswith('PROOFSPEC_P6_19_READONLY_FINALITY_EVIDENCE/')}
    if set(actual)!=expected or len(actual)!=len(expected):
        raise SystemExit('STOP=P6_DIRECTORY_DRIFT')
    for item in files:
        name=item['relative_path']
        f=base/name
        if f.is_symlink() or not f.is_file() or f.stat().st_size!=item['bytes'] or digest(f)!=item['sha256']:
            raise SystemExit('STOP=SOURCE_INTEGRITY_FAILURE:'+name)
    print('R8F_SOURCE_FILES_VERIFIED=29')
    print('R8F_RAW_CONTENT_PRINTED=NO')
    print('R8F_FILES_MODIFIED=NO')
    print('FINAL_RC=0')


if __name__=='__main__':
    main()
