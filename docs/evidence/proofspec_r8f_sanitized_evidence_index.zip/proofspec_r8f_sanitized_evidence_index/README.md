# ProofSpec R8F — Hash-verified forensic inventory (metadata-only)

**Scope:** Studio Next / chain 61997. **Source inventory:** 29 local files verified byte-for-byte against the R8E operator inventory before this package was created. This ZIP contains ONLY filenames, byte counts, SHA-256 digests, provenance and read-only verification instructions. No RPC request/response bodies, transaction journals, source contents, private keys, or access tokens were copied to the ZIP.

**This is not a sanitized release of the original 29 files.** It is a reviewer-facing metadata index, NOT raw transaction proof. File hashes are useful for later correspondence only when the original bytes are made available by the owner under a separately controlled disclosure. Do not infer consensus outcomes from the hashes alone. Do not claim independent audit by the reviewer.

Proven R7 checkpoints (from operator terminal transcripts): Vercel `READY` at release `62589f216adc3041c2f88b65191cd5afd12c7f5d`; public HTTP routes /, /spec/1 and /api/runtime-config returned 200; SDK LATEST_FINAL read reported one `CERTIFIED` spec with `SATISFIED` criterion; primary snapshot verified by contract and independent SHA-256; live Chromium, Firefox and WebKit guest-read tests passed 3/3. Terminal transcript bytes are not included in this ZIP.

The contract's historical deployment/create/evaluate transactions and single successful CERTIFIED outcome are referenced in `docs/PROGRESS_5_6_STUDIO_NEXT_CERTIFICATION_2026-10-16.md` in the repository. The R8 draft PR remains unmerged; `main` and production retain the frozen R7 commit. The original Bradbury/12-write matrix, live REJECTED/INSUFFICIENT and challenges, and live wallet writes are not certified.

## How to verify

1. Check the `SHA256SUMS` file against the included metadata files using `shasum -a 256 -c SHA256SUMS` after unzipping, or `python3 -B verify_local_sources.py --package-only`.
2. If you possess the original source files under `~/Downloads`, run `python3 -B verify_local_sources.py` from this extracted folder. It verifies all 29 bytes/hash combinations and refuses symlinks, unexpected extras, and modified inputs. It **does not print source bytes**.
3. When sharing this ZIP, share its independently reported ZIP SHA-256. Do not share the raw journals or request/response files without a separate, careful content-review and redaction process.

**Safety:** No Git changes, Vercel mutations, signing or blockchain writes are performed.
