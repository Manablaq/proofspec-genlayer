# ProofSpec — Evidence provenance and reviewer limitations

| Source | Claim | Boundary |
| --- | --- | --- |
| R8E terminal inventory | 2 execution journals and 27 P6.19 finality files; zero missing/symlink entries | R8F re-hashes local originals against the exact R8E SHA-256 and byte sizes. |
| P6.19 finalized readback | Studio Next contract `0xD11A506B363E131e8fA3eBeC28a21cC8a4375110` on chain `61997` | Original RPC source bytes remain local; a hash is not the response. |
| R7B direct SDK view checks | spec count 1, challenges 0; spec 1 EVALUATED / CERTIFIED / revision 1, criterion SATISFIED | Observed in the operator's terminal; not recalculated by this packaging action. |
| R7B/R7C evidence inspection | snapshot `f0709a9f292ef5d3c12e2aa30a783eee48670793563c13e2cc159b29982de3f8`; content SHA-256 `db37f823a4e2b2a5446d2c28eb07fef5d9715110fa8f1381d171ad39f00d19e9` | Snapshot hash is a content commitment, not the ZIP digest. Original snapshot content omitted. |
| Vercel / GitHub | live frontend source commit `62589f216adc3041c2f88b65191cd5afd12c7f5d`, production domain `https://proofspec-genlayer.vercel.app` | Documentation PR `61d70960edf3002546d5f5d50e67efb217afc308` is separate/unmerged. |

**Journals and raw RPC payloads intentionally omitted** pending an explicit private-content audit. A reviewer requiring original finality RPC responses must obtain a separately vetted disclosure. This index by itself does not establish new finality, security clearance, Bradbury coverage or full release readiness.
